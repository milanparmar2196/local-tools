$( document ).ready(function() {


  /* $('.navbar-toggle').click(function(){
		$(".mobile-menu").toggleClass('open');
	}); */


  $("#timepicker").datetimepicker({
    format: "LT",
    icons: {
      up: "fa fa-arrow-up",
      down: "fa fa-arrow-down"
    }
  });
  $("#timepicker_to").datetimepicker({
    format: "LT",
    icons: {
      up: "fa fa-arrow-up",
      down: "fa fa-arrow-down"
    }
  });

$('.dropdown-toggle').click(function(e) {
    e.preventDefault();
    e.stopPropagation();
    $(this).closest('.search-dropdown').toggleClass('open');
  });
  
  $('.dropdown-menu > li > a').click(function(e) {
    e.preventDefault();
    var clicked = $(this);
    clicked.closest('.dropdown-menu').find('.menu-active').removeClass('menu-active');
    clicked.parent('li').addClass('menu-active');
    clicked.closest('.search-dropdown').find('.toggle-active').html(clicked.html());
  });
  
  $(document).click(function() {
    $('.search-dropdown.open').removeClass('open');
  });


  let passwordInput = document.getElementById('txtPassword'),
    toggle = document.getElementById('btnToggle'),
    icon =  document.getElementById('eyeIcon');

function togglePassword() {
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
    icon.classList.add("fa-eye-slash");
    //toggle.innerHTML = 'hide';
  } else {
    passwordInput.type = 'password';
    icon.classList.remove("fa-eye-slash");
    //toggle.innerHTML = 'show';
  }
}



toggle.addEventListener('click', togglePassword, false);
passwordInput.addEventListener('keyup', checkInput, false);


$('.radio-btn-design').click(function () {
  $('.radio-btn-design input:not(:checked)').parent().removeClass("radio-selected");
  $('.radio-btn-design input:checked').parent().addClass("radio-selected");
});    

// pirce filter




});


$(function() {
  var $slider = $(".slider-range");
  //Get min and max values
  var priceMin = $slider.attr("data-min"),
     priceMax = $slider.attr("data-max");

  //Set min and max values where relevant
  $("#filter-min, #filter-max").map(function(){
   $(this).attr({
     "min": priceMin,
     "max": priceMax
   });
 });
 $("#filter-min").attr({
   "placeholder": "min " + priceMin,
   "value": priceMin
 });
 $("#filter-max").attr({
   "placeholder": "max " + priceMax,
   "value": priceMax
 });

  $slider.slider({
     range: true,
     min: Math.max(priceMin, 0),
     max: priceMax,
     values: [priceMin, priceMax],
     slide: function(event, ui) {
        $("#filter-min").val(ui.values[0]);
        $("#filter-max").val(ui.values[1]);
     }
  });
 $("#filter-min, #filter-max").map(function(){
   $(this).on("input", function() {
     updateSlider();
   });
 });
 function updateSlider(){
   $slider.slider("values", [$("#filter-min").val(), $("#filter-max").val()]);
 }

 
 $(function(){
	$('.slider-thumb').slick({
		autoplay: false,
		vertical: true,
		infinite: false,
		verticalSwiping: true,
		slidesPerRow: 5,
		slidesToShow: 5,
		asNavFor: '.slider-preview',
		focusOnSelect: true,
		prevArrow: '<a href="#" class="slick-prev"><i class="fas fa-chevron-up"></i></a>',
		nextArrow: '<a href="#" class="slick-next"><i class="fas fa-chevron-down"></i></a>',
		responsive: [
			{
				breakpoint: 767,
				settings: {
					vertical: false,
          arrows:false
				}
			},
			{
				breakpoint: 479,
				settings: {
					vertical: false,
					slidesPerRow: 3,
					slidesToShow: 3,
          arrows:false
				}
			},
		]
	});
	$('.slider-preview').slick({
		autoplay: false,
		vertical: true,
		infinite: false,
		slidesPerRow: 1,
		slidesToShow: 1,
		asNavFor: '.slider-thumb',
		arrows: true,
    prevArrow: '<a href="#" class="main-prev"><i class="fas fa-chevron-left"></i></a>',
		nextArrow: '<a href="#" class="main-next"><i class="fas fa-chevron-right"></i></a>',
		draggable: false,
		responsive: [
			{
				breakpoint: 767,
				settings: {
					vertical: false,
					fade: true,
         
				}
			},
		]
	});
});


 
});

